# -*- coding: utf-8 -*-

import nievecus_hr_general_bpjs
import nievecus_hr_form_bpjs
import inherit_hr